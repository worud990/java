package day08_조건문;
import java.util.Random;
import java.util.Scanner;

public class Ex01_1_복습 {
	/*
	 * # 홀짝 게임
	 * 1. 1~100사이의 랜덤 숫자를 저장한다.
	 * 2. 저장된 랜덤 숫자를 보여주고,
	 * 3. 해당 숫자가 홀수인지 짝수인지 맞추는 게임이다.
	 */
	public static void main(String[] args) {

		Random ran = new Random();
		Scanner scan = new Scanner(System.in);
		
		System.out.println("1.훌수");
		System.out.println("2.짝수");
		
		int num = ran.nextInt(100) + 1;
		System.out.println("num = " + num);
		
		
		System.out.println("번호입력");
		int rNum = scan.nextInt();
		
		if(num % 2 == 1) {
			System.out.println("홀수");
		}
		if(num % 2 == 0) {
			System.out.println("짝수");
		}
		if(num == rNum) {
			System.out.println("정답");
		}
		if(num != rNum) {
			System.out.println("오답");
		}
	}

}
