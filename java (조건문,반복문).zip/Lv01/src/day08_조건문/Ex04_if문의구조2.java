package day08_조건문;

public class Ex04_if문의구조2 {

	/*
	 * # if문의 구조 3가지
	 * 1.
	 * if(조건식){
	 * 		조건식이 참(true)일 떄, 실행할 문장;
	 * }
	 * 
	 * 2.
	 * if(조건식){
	 * 		조건식이 참(true)일 떄, 실행할 문장;
	 * }else{
	 * 		조건식이 거짓(false)일 떄, 실행할 문장;
	 * 
	 * 3.
	 * if(조건식){
	 * 		조건식이 참(true)일 떄, 실행할 문장;
	 * }else if(조건식2){
	 * 		조건식이 참(true)일 떄, 실행할 문장;
	 * }else if(조건식3){
	 * 		조건식이 참(true)일 때, 실행할 문장
	 * }else{
	 * 		위 조건식이 모두 만족하지 않을 떄, 실행할 문장;
	 * }
	 */
	
	public static void main(String[] args) {
		// =====================================
		System.out.println("1.과자 2.음료 3.라면");
		int select = 1;
		if(select == 1) {System.out.println("과자");}
		if(select == 2) {System.out.println("음료");}
		if(select == 3) {System.out.println("라면");}
		else {System.out.println("오류1");} // if만 사용할경우 여기가 출력됨,else if 한개만 연결되기 떄문에
		
		//=======================================
		System.out.println("1.사과 2.포도 3.감");
		select = 1;
		if(select == 1) {System.out.println("포도");}
		else if(select == 2) {System.out.println("사과");}
		else if(select == 3) {System.out.println("감");}
		else {System.out.println("오류2");}
		
		//========================================
		
		
	}

}
