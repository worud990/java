package day08_조건문;
import java.util.Scanner;


public class Ex09_지하철요금문제 {

	/*
	 * # 지하철 요금 계산
	 * 1. 이용할 정거장 수를 입력받는다.
	 * 2. 다음과 같이 정거장 수에 따라 요금이 정산된다.
	 * 3. 요금표
	 * 1) 1~5 : 500원
	 * 2) 6~10 : 600원
	 * 3) 11,12 : 650원 (10정거장 이후는 2정거장마다 50원 추가)
	 * 4) 13,14 : 700원 (10정거장 이후는 2정거장마다 50원 추가)
	 * 5) 15,16 : 750원 (10정거장 이후는 2정거장마다 50원 추가)
	 * ...
	 */
	
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		System.out.println("이용하실 정거장 번호입력");
		int station = scan.nextInt();

		int ticket = 0;

		if (station <= 5) { // 1~5까지의 범위
			ticket = 500;
		} else if (station <= 10) { // 6~10까지의 범위
			ticket = 600;
		} else {
			ticket = 650 + ((station - 11)/2) *50;
		}

		System.out.println("지하철 요금은 " + ticket + "원입니다.");
	}

}
