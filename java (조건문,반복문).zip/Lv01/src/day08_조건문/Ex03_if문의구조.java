package day08_조건문;

public class Ex03_if문의구조 {

	/*
	 * #if문의 구조 3가지
	 * 1.
	 * if(조건식){
	 * 		조건식이 참(true)일 떄, 실행할 문장;
	 * }
	 * 
	 * 2.
	 * if(조건식){
	 * 		조건식이 참(true)일 떄, 실행할 문장;
	 * }else{
	 * 		조건식이 거짓(false)일 떄, 실행할 문장;
	 * }
	 * 
	 * 3.
	 * if(조건식1){
	 * 		조건식1이 참(true)일 떄, 실행할 문장;
	 * }else(조건식2){
	 * 		조건식2가 참(true)일 떄, 실행할 문장;
	 * }else(조건식3){
	 * 		조건식3이 참(true)일 떄, 실행할 문장;
	 * }else{
	 * 		위 조건이 모두 만족하지 않을 떄, 실행할 문장;
	 * }
	 */
	public static void main(String[] args) {

		//예) 홀짝
		int num = 10;
		if(num % 2 ==0) {
			System.out.println("짝수");
		}
		if(num % 2 ==1) {
			System.out.println("홀수");
		}
		System.out.println("---------------------------");
		/*
		 * 실행할 문장이 1문장인 경우,
		 * 블럭{}을 생략할 수 있다.
		 * 하지만 권장하지 않는다!
		 */
		if(num % 2 == 0)
			System.out.println("짝수");
		if(num % 2 == 1)
			System.out.println("홀수");
		
		System.out.println("----------------------------");
		
		if(num % 2 == 0){
			System.out.println("짝수");
		}
		else{
			System.out.println("홀수");
		}
	}

}
