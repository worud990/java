package day08_조건문;

import java.util.Random;
import java.util.Scanner;

public class Ex08_1_복습 {
	/*
	 * # 369게임[1단계]
	 * 1. 1~50 사이의 랜덤 숫자를 저장한다.
	 * 2. 위 수에 369의 개수가
	 * 	1)2개이면, 짝짝을 출력
	 * 	2)1개이면, 짝을 출력
	 * 	3)0개이면, 해당 숫자를 입력
	 * 예)
	 * 		33 : 짝짝
	 * 		16 : 짝
	 * 		7  : 7
	 */
	
	public static void main(String[] args) {
		
		Random ran = new Random();
		Scanner scan = new Scanner(System.in);
		
		
		int num = ran.nextInt(50) + 1;
		System.out.println("num = " + num);
		
		int rNum1 = num % 100 / 10;
		int rNum2 = num % 10;
		
		System.out.println("숫자입력");
		int su = scan.nextInt();
		
		if((rNum1 == 3 || rNum1 == 6 || rNum1 == 9) && (rNum2 == 3 || rNum2 == 6 || rNum2 == 9)) {
			System.out.println("짝짝");
		}else if((rNum2 == 3 || rNum2 == 6 || rNum2 == 9) || (rNum1 == 3 || rNum1 == 6 || rNum1 ==9)) {
			System.out.println("짝");
		}else {
			System.out.println(num);
		}
	
		
	}

}
