package day08_조건문;

import java.util.Scanner;
import java.util.Random;

public class Ex08_369게임문제 {
	/*
	 * # 369게임[1단계]
	 * 1. 1~50 사이의 랜덤 숫자를 저장한다.
	 * 2. 위 수에 369의 개수가
	 * 	1)2개이면, 짝짝을 출력
	 * 	2)1개이면, 짝을 출력
	 * 	3)0개이면, 해당 숫자를 입력
	 * 예)
	 * 		33 : 짝짝
	 * 		16 : 짝
	 * 		7  : 7
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Random ran = new Random();
		
		int num = ran.nextInt(50) +1;
		System.out.println("num = " +num);
		
		int rNum1 = num % 100/10; // 십의 자리
		int rNum = num % 10;  // 일의 자리
		
		System.out.println(num +"의 숫자입력");
		int su = scan.nextInt();
		
		if((rNum1 == 3 || rNum1 == 6 || rNum1 == 9) && (rNum == 3 || rNum == 6 || rNum == 9)) { // 십의 자리
			System.out.println("짝짝");
		}else if((rNum == 3 || rNum == 6 || rNum == 9) || (rNum1 == 3 || rNum1 == 6 || rNum1 == 9)) { // 일의 자리
			System.out.println("짝");
		}else {
			System.out.println(num);
		}
	}
	

}
