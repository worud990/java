package day08_조건문;

import java.util.Scanner;
import java.util.Random;

public class Ex01_홀짝게임문제 {

	/*
	 * # 홀짝 게임
	 * 1. 1~100사이의 랜덤 숫자를 저장한다.
	 * 2. 저장된 랜덤 숫자를 보여주고,
	 * 3. 해당 숫자가 홀수인지 짝수인지 맞추는 게임이다.
	 */
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		Random ran = new Random();
		
		System.out.println("1.홀수");
		System.out.println("2.짝수");
		
		int su = ran.nextInt(100) + 1;
		System.out.println(su);
		
		System.out.println("번호를 선택하세요 :");
		int choice = scan.nextInt();
	
		
		if(su % 2 ==0) {
			System.out.println("짝수");
		}
		if(su % 2 == 1) {
			System.out.println("홀수");
		}
		
		if(choice == su) {
			System.out.println("정답");
		}
		
		if(choice != su) {
			System.out.println("틀렸다");
		}
	}

}
