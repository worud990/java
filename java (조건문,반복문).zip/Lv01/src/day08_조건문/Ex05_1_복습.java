package day08_조건문;

import java.util.Random;
import java.util.Scanner;

public class Ex05_1_복습 {
	/*
	 * # 가위바위보 게임[2단계]를
	 * 	if ~ else if 구문으로 변경해보자.
	 */
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		Random ran = new Random();
		
		int com = ran.nextInt(3);
		
		System.out.println("0~2사이의 숫자 입력");
		int me = scan.nextInt();
		
		if(me == com) {
			System.out.println("비겼다.");
		}else if(me == 0 && com == 2) {
			System.out.println("내가 이겼다.");
		}else if(me == 1 && com == 0) {
			System.out.println("내가 이겼다.");
		}else if(me == 2 && com == 1) {
			System.out.println("내가 이겼다.");
		}else if(com == 0 && me == 2) {
			System.out.println("내가 졌다.");
		}else if(com == 1 && com == 0) {
			System.out.println("내가 졌다.");
		}else if(com == 2 && me == 1){
			System.out.println("내가 졌다.");
		}else {
			System.out.println("종료");
		}
	}

}
