package day05;

import java.util.Scanner;

public class Ex04_1_복습 {
	/*
	 * # 로그인[2단계]
	 * 1. Id와 Pw를 입력받아 회원가입을 진행한다.
	 * 2. 이후 로그인을 위해 다시 Id와 Pw를 입력받는다.
	 * 3. 가입 후 저장된 데이터와 로그인 시 입력받은 데이터를 비교한다.
	 * 예) 로그인 성공 or 로그인 실패
	 */
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		int dbId = 0;
		int dbPw = 0;
		
		System.out.println("가입하실 아이디 입력");
		int dbid = scan.nextInt();
		
		System.out.println("비밀번호 입력");
		int dbpw = scan.nextInt();
		
		if(dbId == dbid) {
			System.out.println("회원가입 완료");
		}
		System.out.println();
		
		if(dbId == dbid) {
			System.out.println("가입하신 아이디 입력");
			dbid = scan.nextInt();
		}
		if(dbPw == dbpw) {
			System.out.println("비밀번호 입력");
			dbpw = scan.nextInt();
		}
		if(dbId == dbid && dbPw == dbpw) {
			System.out.println("로그인 성공");
		}
		if(dbPw != dbpw || dbId != dbid) {
			System.out.println("로그인 실패");
		}
	}

}
