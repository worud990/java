package day05;

import java.util.Scanner;

public class Ex04_회원가입로그인_조건문 {
	/*
	 * # 로그인[2단계]
	 * 1. Id와 Pw를 입력받아 회원가입을 진행한다.
	 * 2. 이후 로그인을 위해 다시 Id와 Pw를 입력받는다.
	 * 3. 가입 후 저장된 데이터와 로그인 시 입력받은 데이터를 비교한다.
	 * 예) 로그인 성공 or 로그인 실패
	 */
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		int dbId = 0;
		int dbPw = 0;

		System.out.print("가입하실 아이디를 입력해주세요. ");
		int logid = scan.nextInt();

		System.out.print("비밀번호 입력해주세요. ");
		int logpw = scan.nextInt();

		if (dbId == dbPw) {
			System.out.println("회원가입 성공!!");
			
		}
		if (dbId == logid) {
			System.out.println("가입한 아이디 입력");
			logid = scan.nextInt();
		}
		if (dbId == logpw) {
			System.out.println("비밀번호 입력해주세요.");
			logpw = scan.nextInt();
		}
		if (dbId == logid && dbPw == logpw) {
			System.out.println("로그인 성공");
		}

		if (dbId != logid || dbPw != logpw) {
			System.out.println("로그인 실패");
		}
		
	}

}
