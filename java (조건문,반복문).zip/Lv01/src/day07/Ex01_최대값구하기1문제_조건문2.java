package day07;

import java.util.Scanner;

public class Ex01_최대값구하기1문제_조건문2 {
  // 6월 5일 
	/*
	 * # 최대값 구하기[1단계]
	 * 1. 숫자 3개를 입력받는다.
	 * 2. 입력받은 3개의 수를 비교해서
	 * 3. 가장 큰 수(MAX)를 출력한다.
	 */
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		
		
		System.out.println("a의값");
		int a = scan.nextInt();
		
		System.out.println("b의값");
		int b = scan.nextInt();
		
		System.out.println("c의 값");
		int c = scan.nextInt();
		
		int max = a;
		max = a;
		
		if(max<b) {
			max = b;
		}
		if(max<c) {
			max = c;
		}
		
		System.out.println("가장 큰 수 " + max + "입니다.");
		
		}
	}

