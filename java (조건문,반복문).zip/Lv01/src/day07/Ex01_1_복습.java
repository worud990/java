package day07;
import java.util.Scanner;
public class Ex01_1_복습 {
	/*
	 * # 최대값 구하기[1단계]
	 * 1. 숫자 3개를 입력받는다.
	 * 2. 입력받은 3개의 수를 비교해서
	 * 3. 가장 큰 수(MAX)를 출력한다.
	 */
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		System.out.println("a의 값 입력");
		int a = scan.nextInt();
		
		System.out.println("b의 값 입력");
		int b = scan.nextInt();
		
		System.out.println("c의 값 입력");
		int c = scan.nextInt();
		
		int max = a;
		max = a;
		
		if(a<b) {
			max = b;
		}
		if(a<c) {
			max = c;
		}
		
		System.out.println("가장 큰 수는 " + max + "이다.");
	}

}
