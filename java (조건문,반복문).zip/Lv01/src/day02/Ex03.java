package day02;

public class Ex03 {

	public static void main(String[] args) {

		// 예) 현금이 1000원있다. 200원짜리 과자 구입 후. 잔돈 출력

		int 현금 = 1000;
		int 과자 = 200;
		int 잔돈 = 현금 - 과자;
		System.out.println("잔돈 = " + 잔돈 + "원");

		// 문1) 월급이 100원이다. 연봉은? (조건 : 세금 10% 제외)
		int 월급;
		월급 = 100;
		double 세금;
		세금 = 0.1;
		int dNum;
		dNum = 12;
		System.out.println("연봉 = " + 월급 * dNum + "원");
		System.out.println("월급 = " + 월급 * 세금 + "원");

		// 문2) 시험점수를 30,50,4점을 받았다. 평균은?
		int a;
		a = 30 + 50 + 4;
		int 평균 = a / 3;
		System.out.println("평균 = " + 평균);

		// 문3) 가로가 3이고 세로가 6인 삼각형 넓이 출력
		int 가로;
		가로 = 3;
		int 세로;
		세로 = 6;
		int 넓이;
		넓이 = 가로 * 세로 / 2;
		System.out.println("넓이 = " + 넓이);

		// 문4) 100초를 1분 40초로 출력
		int num;
		num = 100 % 60;
		System.out.println("1분" + num + "초");

		// 문5) 800원에서 500원짜리 개수, 100원짜리 개수
		// 정답) 500(1개). 100(3개)
		int num2;
		num2 = 800 - 300;
		int num3;
		num3 = 800 - 500;
		int num4;
		num4 = 800 / 500; // 500원짜리 개수
		int num5;
		num5 = 800 & 300 / 100; // 100원짜리 개수
		System.out.println(num2 + "원" + num4 + "개" + num3 + "원" + num5 + "개");
	}

}
