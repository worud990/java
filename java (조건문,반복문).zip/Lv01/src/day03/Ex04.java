package day03;

public class Ex04 {

	public static void main(String[] args) {

		//예) 3의 배수이면서,짝수이면 true 출력
		int num = 12;
		System.out.println(num % 3 == 0 && num % 2 == 0);
		
		//문1) 과목
		//3과목의 평균이 60점 이상이면,true
		//단, 어느 한 과목이라도 50점 미만이면, false
		int kor = 100;
		int eng = 87;
		int math = 41;
		int 평균 = 100+87+41/3;
		
		System.out.println(kor>50 && eng>50 && math>50 && 평균>=60);
	
		//문2) 키가 200cm이상이거나 몸무게가 200kg 이상이면, 입장(true)
		int num2 = 220; // 키
		int num3 = 210; // 몸무게
	    int num4 = 200; 
	    
	    System.out.println(num2>num4 && num3>num4);
	   
	
		
		
	}

}
