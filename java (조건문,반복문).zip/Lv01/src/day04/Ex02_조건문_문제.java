package day04;

public class Ex02_조건문_문제 {

	public static void main(String[] args) {

		int a = 10;
		int b = 10;
		if(a == b) {
			System.out.println("실행 O");
		}
		if(a != b) {
			System.out.println("실행 X");
		}
		
		//문1) 양수,0,음수 출력
		int num1 = -10;
		System.out.println(num1 % 2 == 0);{
			if(num1>0) {
				System.out.println(num1 + "은 양수다");
			}
			if(num1==0) {
				System.out.println(num1 + "은 0이다");
			}
			if(num1<0) {
				System.out.println(num1 + "은 음수다");
			}
		}		
		
		//문2) 4의 배수 여부 출력
		int num2 = 12;
		System.out.println(num2 % 4 == 0);
		if(num2 % 4 == 0) {
			System.out.println(num2 + "는 4의배수다");
		}
		
		//문3) 합격, 불합격 출력
		int score = 87;
		if(score>60) {
			System.out.println(score>60);
			System.out.println(score + "점은 합격입니다.");
		}
		if(score<60) {
			System.out.println(score<60);
			System.out.println(score + "점은 불합격입니다.");
		}
		
		
	

	}
}
