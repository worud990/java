package day04;

public class Ex01_조건문 {

	/*
	 * # 조건문 if
	 * 
	 * 1) if ==> 키워드
	 * 2) (조건식) ==> 조건이 사실이면 기능 실행
	 * 3) {기능} ==> 기능 실행
	 * 
	 * if(조건식){
	 *  	조건식이 참(true)일 떄 실행할 문장;
	 *  }
	 *  
	 */
	public static void main(String[] args) {
		
		
		int a = 10;
		int b = 10;
        if(a == b) {
        	System.out.println("실행 o");
        }
        
        if(a != b) {
        	System.out.println("실행 x");
        }
        
        //예) 홀짝
        int num = 8;
        System.out.println(num % 2 == 0); // 짝수
        System.out.println(num % 2 == 1); // 홀수
        
        if(num % 2 == 0) {
        	System.out.println("짝수");
        }
        if(num % 2 == 1) {
        	System.out.println("홀수");
        }
		
	}

}
