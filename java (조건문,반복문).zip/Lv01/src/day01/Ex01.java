package day01;

public class Ex01 {

	public static void main(String[] args) {

		// 자료형(Data Type)
		
				// 1. 숫자(정수) : 소수점이 없는 수
				System.out.println(10);
				// 2. 숫자(실수) : 소수점이 있는 수
				System.out.println(3.14);
				// 3. 문자 한 개 : 홑따옴표
				System.out.println('B');
				// 4. 문자 여러개 : 쌍따옴표
				System.out.println("Java Class");	
	}

}
