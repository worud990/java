package day13_기타문법;

public class Ex01_조건문switch1 {
	/*
	 * 스위치 케이스 (switch case)
	 * 사용예 : 비교대상이 전부 == 일떄만 사용가능
	 * 모양이 많이 불편하다 (그냥 if문 쓰는게 낫다)
	 * 
	 * 1) switch ==> 키워드
	 * 2) (값) ==> 비교할값
	 * 3) {}  ==> 영역
	 * 4) case 값: ==> 비교할값
	 * 5) 내용 break ==> 비교할값과내용
	 * 
	 */
	public static void main(String[] args) {
		
		int a = 2;
		//----------------------------------
		if(a == 1) {
			System.out.println("a는 1이다");
		}else if(a ==  2) {
			System.out.println("a는 2이다");
		}else if(a == 3) {
			System.out.println("a는 3이다");
		}
		//-----------------------------------
		switch(a) {
		case 1 :
			System.out.println("a는 1이다");
			break;
		case 2 :
			System.out.println("a는 2이다");
			break;
		case 3 :
			System.out.println("a는 3이다");
			break;
		}
	}

}
