package day13_기타문법;

public class asd {

	public static void main(String[] args) {
		   // #문제 1) 8 과 12 의 최소 공배수를 구하시요
        System.out.println("문제1) 8과 12의 최소공배수");
        System.out.println("8의 배수");
        for (int i = 1; i < 100; i++) {
            if (i % 8 == 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
        System.out.println("12의 배수");
        // 1-2 12의 배수
        for (int i = 1; i < 100; i++) {
            if (i % 12 == 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
        System.out.println();

        System.out.println("8과 12의 최소공배수");
        int cnt1 = 0; // 공통 수를 카운트
        for (int i = 1; true; i++) {
            if (i % 8 == 0 && i % 12 == 0) { // 8과 12의 배수를 나열하기
                System.out.print(i + " ");
                cnt1++; // 배열 수를 카운트
            }
            if (cnt1 == 1) { // 첫번째 나오는 수가 최소공배수
                break;
            }
        }
        System.out.println();
        System.out.println();

        // # 문제2) 수인이는 4일 마다 수영장을 가고 형주는 6일마다 수영장에간다
        // # 두사람이 4월 3일에 만났다면 다음에 만날날은 언제인가?
        System.out.println("문제2) 다음 수영장에서 만나는 날");

        // 두 사람이 각각 가는 날의 배수가 같은 때
        int cnt2 = 0;
        for (int i = 1;; i++) {
            if (i % 4 == 0 && i % 6 == 0) {
                System.out.println("4월 " + (3 + i) + "일 ");
                cnt2++;
            }
            if (cnt2 == 1) {
                break;
            }
        }
        System.out.println();

        // # 문제3) 가로가 12 이고 세로가 8인 직사각형모양의 종이를 늘어놓아
        // # 만들수있는 가장작은 정사각형을 만들려고한다. 직사각형은몇장이 필요한가?
        System.out.println("문제3) 정사각형을 위한 최소 필요 종이");
        System.out.println("가로 최소길이");
        int cnt3 = 0;
        for (int i = 1; i < 100; i++) {
            if (i % 12 == 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
        System.out.println("세로 최소길이");
        for (int i = 1; i < 100; i++) {
            if (i % 8 == 0) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
        System.out.println("최소 공배수");
        for (int i = 1;; i++) { // 12와 8의 최소공배수
            if (i % 12 == 0 && i % 8 == 0) {
                System.out.println(i); // 한 변의 최소 길이
                cnt3++;
            }
            if (cnt3 == 1) {
                break;
            }
        }
        System.out.println();
        System.out.println("1장당 넓이: " + 12 * 8 + "cm"); // 96
        System.out.println("최소 정사각형 넓이: " + 24 * 24 + "cm"); // 576

        int paper = 0;
        for (int i = 96; i <= 576; i += 96) {
            paper++; // 장수 계산
        }
        System.out.println();
        System.out.println(paper + "장 필요");

	}

}
