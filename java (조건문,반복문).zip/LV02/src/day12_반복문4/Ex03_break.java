package day12_반복문4;
import java.util.Scanner;
public class Ex03_break {
	/*
	 * # 보조제어문 1.break 반복문 1개를 즉시 종료 (굉장히 편리하다)
	 */
	public static void main(String[] args) {

		// break
		for(int i = 0; i < 15; i++) {
			if(i > 3) {
				break;
			}
			System.out.println(i);
		}
			System.out.println("종료");
	}
}
