package day12_반복문4;

public class Ex02_for기본1문제 {

	public static void main(String[] args) {

		// for 를 사용해서 풀어보자
		
		// 문제 1) 1부터 5까지 출력
		// 정답 1) 1, 2, 3, 4, 5
		
		for(int x = 1; x <= 5; x++) {
			System.out.print(x +",");
		}
		
		
		System.out.println();
		
		// 문제 2) 1부터 10까지 반복해,5~9까지 출력
		// 정답 2) 5, 6, 7, 8, 9
		
		for(int y = 1; y <= 10; y++) {
			if(y <= 9 && y >= 5) {
				System.out.print(y + ",");
			}
		}
		
		System.out.println();
		
		// 문제 3) 10부터 1까지 반복해 6~3까지 출력
		// 정답 3) 6, 5, 4, 3,
		
		for(int z = 10; z >= 1; z--) {
			if(z <= 6 && z >= 3) {
				System.out.print(z + ",");
			}
		}
		
		System.out.println();
		
		//문제4) 1부터 10까지 반복해 3미만 7이상 출력
		//정답4) 1,2,7,8,9,10
		
		for(int a = 1; a <= 10; a++) {
			if(a < 3 || a > 7) {
				System.out.print(a + ",");
			}
		}
		
	}

}
