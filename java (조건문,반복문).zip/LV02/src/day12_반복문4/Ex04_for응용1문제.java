package day12_반복문4;

public class Ex04_for응용1문제 {

	public static void main(String[] args) {
		
		// for를 사용해서 풀어보세요
		//문제1) 9의 배수중 일의 자리가 6인 첫번쨰 배수 출력 ==> 답 : 36
		for(int i =9; ;i += 9) {
			if(i % 10 == 6) {
				System.out.println("답 : " +i);
				break;
			}
		}
		//문제2) 9의 배수중 십의 자리가 6인 첫번쨰 배수 출력 ==> 답 : 63
		for(int i = 9; ;i += 9) {
			if(i / 10 == 6) {
				System.out.println("답 : " + i);
				break;
			}
		}
		
		//문제3) 8의 배수중 150보다 작고 150에 가장 가까운 수를 출력 ==> 답 : 144
		int num = 0;
		for(int i = 8; i < 150; i+=8) {
			if(i > 150) {
				break;
			}
			num = i;
		}
		System.out.println("답 : " + num);
	
	}

}
