package day11_반복문3;
import java.util.Scanner;
public class Ex01_쇼핑몰뒤로가기문제 {
	/*
	 * # 쇼핑몰 뒤로가기
	 * 
	 * 문제) 쇼핑몰 메인메뉴에서 남성의류 선택해서
	 * 		뒤로가기 누르기전까지 남성의류 페이지를 유지하려고한다.
	 * 힌트) 계층 별로 반복문을 추가 해주면된다.
	 * 1.남성의류
	 * 		1) 티셔츠
	 * 		2) 바지
	 * 		3) 뒤로가기
	 * 2.여성의류
	 * 		1) 가디건
	 * 		2)치마
	 * 		3)뒤로가기
	 * 3. 종료
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		boolean run = true;
		while(run) {
			System.out.println("1.남성의류");
			System.out.println("2.여성의류");
			System.out.println("3.종료");
			
			System.out.println("메뉴 선택 : ");
			 int sel = scan.nextInt();
			 
			 if(sel == 1) {
				 boolean isrun = true;
				 while(isrun) {
					 System.out.println("1)티셔츠");
					 System.out.println("2)바지");
					 System.out.println("3)메뉴 페이지로 이동");
					 
					 System.out.println("메뉴 선택 : ");
					 int select = scan.nextInt();
					 
				
					 if(select == 1) {
						 System.out.println("티셔츠 페이지 입니다.");
					 }else if(select == 2) {
						 System.out.println("바지 페이지 입니다.");
					 }else if(select == 3) {
						 isrun = false;
						 System.out.println("메뉴 페이지로 이동");
					 }else {
						 System.out.println("잘못입력했습니다.");
					 }
				 }
			 }
			 else if(sel == 2) {
				 boolean isrun = true;
				 while(isrun) {
					 System.out.println("1)가디건");
					 System.out.println("2)치마");
					 System.out.println("3)뒤로 가기");
					 
					 System.out.println("메뉴 선택 : ");
					 int select = scan.nextInt();
					 
					 if(select == 1) {
						 System.out.println("가디건 페이지 입니다.");
					 }else if(select == 2) {
						 System.out.println("치마 페이지 입니다.");
					 }else if(select == 3) {
						 isrun = false;
						 System.out.println("메뉴 페이지로 이동");
					 }else {
						 System.out.println("잘못입력했습니다.");
					 }
				 }
			 }
			 else if(sel == 3) {
				 run = false;
				 System.out.println("프로그램 종료");
			 }else {
				 System.out.println("잘못입력했습니다.");
			 }
		}
	}
}
