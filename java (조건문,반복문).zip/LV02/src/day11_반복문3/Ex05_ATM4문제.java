package day11_반복문3;

import java.util.Scanner;

public class Ex05_ATM4문제 {
	/*
	 * # ATM[종합]
	 * 1.로그인
	 * . 로그인 후 재 로그인 불가
	 * . 로그아웃 상태에서만 이용가능
	 * 2.로그아웃
	 * . 로그인 후 이용가능
	 * 3.입금
	 * .로그인 후 이용가능
	 * 4.출금
	 * . 로그인 후 이용가능
	 * 5.이체
	 * . 로그인 후 이용가능
	 * 6.조회
	 * . 로그인 후 이용가능
	 * 7.종료
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		int dbAcc1 = 1111;
		int dbPw1 = 1234;
		int dbMoney1 = 50000;
		
		int dbAcc2 = 2222;
		int dbPw2 = 2345;
		int dbMoney2 = 70000;
		
		int log = -1;				// -1(로그아웃),1(dbAcc1로그인),2(dbAcc2로그인)
		
		boolean run = true;
		while(run) {
			
			System.out.println("1.로그인");
			System.out.println("2.로그아웃");
			System.out.println("3.입금");
			System.out.println("4.출금");
			System.out.println("5.이체");
			System.out.println("6.조회");
			System.out.println("0.종료");
			
			System.out.println("메뉴 선택 : ");
			int sel = scan.nextInt();
			
			if(sel == 1) {
				if(log == -1) {
					System.out.println("ID 입력 : ");
					int myid = scan.nextInt();
					
					System.out.println("PW 입력 : ");
					int mypw = scan.nextInt();
					
					if(myid == dbAcc1 && mypw == dbPw1) {
						System.out.println("dbAcc1 로그인 됐습니다");
						log = 1;
					}else if(myid == dbAcc2 && mypw == dbPw2) {
						System.out.println("dbAcc2 로그인 됐습니다");
						log = 2;
					}else {
						System.out.println("ID와 PW를 확인해주세요");
					}
				}else {
					System.out.println("이미 로그인 됐습니다");
				}
			}else if(sel == 2) {
				if(log == -1) {
					System.out.println("로그인 후 이용가능 합니다");
				}else {
					log = -1;
					System.out.println("로그아웃 됐습닌다");
				}
			}else if(sel == 3) {
				if(log == -1) {
					System.out.println("로그인이 필요합니다");
				}else {
					System.out.println("입금하실 계좌번호를 입력하세요");
					int Acc1 = scan.nextInt();
					System.out.println("입급할 금액을 입력하세요");
					int money1 = scan.nextInt();
					
					if(log == 1 && Acc1 == dbAcc1) {
						dbMoney1 += money1;
						System.out.println("dbAcc1에 입급됐습니다");
					}else if(log == 2 && Acc1 == dbAcc2) {
							dbMoney2 += money1;
							System.out.println("dbAcc2에 입금됐습니다");
					}else {
						System.out.println("맞지않는 계좌번호입니다");
					}
					
				}
			}else if(sel == 4) {
				if(log == -1) {
					System.out.println("로그인이 필요합니다");
				}else {
					System.out.println("출금할 계좌번호 입력하세요");
					int Acc2 = scan.nextInt();
					System.out.println("출금하실 금액을 입력하세요");
					int money2 = scan.nextInt();
					
					if(log == 1 && Acc2 == dbAcc1) {
						if(Acc2 <= dbMoney1) {
							dbMoney1 -= money2;
							System.out.println("출금되었습니다");
						}else {
							System.out.println("잔액이 부족합니다");
						}
					}else if(log == 2 && Acc2 == dbAcc2) {
						if(Acc2 <= dbMoney2) {
							dbMoney2 -= money2;
							System.out.println("출금되었습니다");
						}else {
							System.out.println("맞지않는 계좌번호입니다");
						}
					}
				}
			}else if(sel == 5) {
				if(log == -1) {
					System.out.println("로그인이 필요합니다");
				}else {
					System.out.println("이체할 계좌번호 입력해주세요");
					int Acc2 = scan.nextInt();
					if(Acc2 == dbAcc2) {
						System.out.println("이체할 금액을 입력해주세요");
						int money3 = scan.nextInt();
						if(Acc2 <= dbMoney1) {
							dbMoney1 -= money3;
							dbMoney2 += money3;
							System.out.println("이체가 완료됐습니다");
						}else {
							System.out.println("이체하실 금액이 초과하여 이체하실 수 없습니다");
						}
					}else {
						System.out.println("계좌번호가 맞지않습니다");
					}
				}
			}else if(sel == 6) {
				System.out.println("dbMoney1 잔액 : " + dbMoney1 + "원");
				System.out.println("dbMoney2 잔액 : " + dbMoney2 + "원");
			}else if(sel == 0) {
				run = false;
				System.out.println("프로그램 종료");
			}else {
				System.out.println("잘못입력했습니다 다시입력해주세요");
			}
		}
		
	}

}
