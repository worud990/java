package day10_반복문2;

public class EX01_1_복습 {

	public static void main(String[] args) {

		//문제1) 9의 배수중 일의 자리가 6인 첫번쨰 배수 출력 => 답 : 36
		int i = 9;
		while(i % 10 != 6) {
			i = i + 9;
		}
		System.out.println("답 : " + i);
		//문제2) 9의 배수중 십의 자리가 6인 첫번쨰 배수 출력 => 답 : 63
		 i = 9;
		 while(i / 10 != 6) {
			 i = i + 9;
		 }
		 System.out.println("답 : " + i);
		//문제3) 8의 배수중 150보다 작고 150에 가장 가까운수를 출력 => 답 : 144
		 int su = 8;
		 while(i < 150) {
			 if(i > su) {
				 su = i + 1;
			 }
			i = i + 8;
		 }
		 System.out.println("답 : " + su);
	}

}
