package day10_반복문2;
import java.util.Random;
public class Ex07_랜덤학생문제 {
	/*
	 * # 랜덤학생
	 * 1.10회 반복을 한다.
	 * 2.1~100사이의 랜덤 숫자를 저장한다.(학생의성적)
	 * 3.성적이 60점 이상이면 합격생이다.
	 * ----------------------------------
	 * .전교생(10명)의 총점과 평균을 출력한다.
	 * .합격자 수를 출력한다.
	 * .1등 학생의 번호와 성적을 출력한다.
	 * 
	 */
	public static void main(String[] args) {
		Random ran = new Random();
		
		int total = 0; // 총점
		int pass = 0; // 합격자 수
		int topscore = 0; // 1등 성적
		int topnum = 0; // 1등 번호
	
		int count = 0;
		while(count <= 10) {
			int score = ran.nextInt(100) + 1;
			total+= score;
			
			if(score >= 60) {
				pass++;
			}
			if(score > topscore) {
				topscore = score;
				topnum = count;
			}
			count++;
		}
			System.out.println("전교생 총점 : " + total + "점");
			System.out.println("전교생 평균 : " + total/10 + "점");
			System.out.println("합격자 수 : " + pass + "명");
			System.out.println("1등 번호 : " + topnum + "번");
			System.out.println("1등 성적 : " + topscore + "점");
	}
		

}
