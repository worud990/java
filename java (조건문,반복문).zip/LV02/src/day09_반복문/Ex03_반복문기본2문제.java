package day09_반복문;

public class Ex03_반복문기본2문제 {

	public static void main(String[] args) {
		// 문제1) 1~5까지의 합 출력
		// 정답1) 15
		int i = 1;
		int total = 0;
		while(i<=5) {
			if(i<=5) {
				total = total + i;
			}
			i = i + 1;
		}
		System.out.println(total);
		// 문제2) 1~10까지의 반복해 3미만 7이상만 출력
		// 정답2) 1,2,7,8,9,10
		int x = 1;
		while(x <= 10) {
			if(x < 3 || x >= 7) {
				System.out.print(x + " ");
			}
			x = x + 1;
		}
		System.out.println();
		// 문제3) 문제2의 조건에 맞는 수들의 합 출력
		// 정답3) 37
		x = 1;
		total = 0;
		while(x <= 10) {
			if(x < 3 || x >= 7) {
				total = total + x;
			}
			x = x + 1;
		}
		System.out.println(total);
		// 문제4) 문제2의 조건에 맞는 수들의 개수를 출력
		// 정답4) 6
		x = 1;
		int count = 0;
		while(x <= 10) {
			if(x < 3 || x >= 7) {
				count = count + 1;
			}
			x = x + 1;
		}
		System.out.println(count);
	}

}
