package day09_반복문;

public class Ex01_반복문이론 {
	/*
	 * # 반복문 while
	 * # 구조
	 * 1) while ==> 키워드
	 * 2) (조건식) ==> 조긴이 사실이면 기능실행
	 * 3) {기능} ==> 반복문은 if문 와 다르게 기능 종료후 다시 while 실행
	 * 4) 중요 ==> 반복문은 반드시 종료 조건을 만들어야한다. (무한반복 방지)
	 */
	
	public static void main(String[] args) {
		//예) 1~5까지 출력
		int i = 1;  // 초기식
		while(i <= 5) { // 조건식
			System.out.println(i);
			i = i + 1;
		}
		// 증감식 종류 (아래 4종류 전부 같은뜻이다)
		//1) i = i + 1;
		//2) i += i;
		//3) i++;
		//4) ++i;

	}

}
