package day09_반복문;
import java.util.Random;
import java.util.Scanner;
public class Ex06_1_복습 {
	/*
	 * # Up & Down 게임[2단계]
	 * 1. com은 랜덤으로 1~100사이를 저장한다.
	 * 2. me는 1~100사이를 입력한다.
	 * 3. com 과 me를 비교해서 com 크면 "크다" , com이 작으면 "작다" 힌트제공
	 * 4. 정답을 맞추면 게임은 종료된다.
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Random ran = new Random();
		
		System.out.println("Up & Down 게임");
		
		int com = ran.nextInt(100)+ 1;
		System.out.println(com);
		
		
		int me = 0;
		while(com != me) {
			
			System.out.println("1~100사이 숫자 입력");
			me = scan.nextInt();
			
			if(com > me) {
				System.out.println(me +"보다 크다");
				
			}else if(com < me) {
				System.out.println(me +"보다 작다");
				
			}else if(com == me) {
				System.out.println("정답");
			}
		}
	}

}
