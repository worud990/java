package day09_반복문;

import java.util.Scanner;
import java.util.Random;

public class Ex04_구구단게임3문제 {
	/*
	 * # 구구단 게임[3단계]
	 * 1. 구구단 게임을 5회 반복한다.
	 * 2. 정답을 맞추면 개당 20점이다.
	 * 3. 게임 종료 후, 성적을 출력한다.
	 */
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Random ran = new Random();

		int i = 1;
		int score = 0;
			
		while(i<=5) {
			int num1 = ran.nextInt(9) + 1;
			int num2 =ran.nextInt(9) + 1;
			int rNum = num1 * num2;
			
			System.out.println(num1 + " X " + num2 + " = " + " ? ");
			
			System.out.print("정답 :");
			int answer = scan.nextInt();
			
			if(rNum == answer) {
				System.out.println("정답");
				score = score + 20;
			}else {
				System.out.println("오답");
			}
			i = i + 1;
		}
			System.out.println("게임종료");
			System.out.println("총점은 " + score + "점입니다.");
	}
}
