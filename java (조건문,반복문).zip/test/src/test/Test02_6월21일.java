package test;
//시작 : 15 : 51
//종료 : 16 : 50
//소요 : 1시간 소요
import java.util.Scanner;
import java.util.Random;

public class Test02_6월21일 {

public static void main(String[] args) {
	/*
	 * # 구구단 게임[2단계]
	 * 1. 구구단 문제를 출제하기 위해 숫자 2개를 랜덤으로 저장한다.
	 * 2. 저장된 숫자를 토대로 구구단 문제를 출력한다.
	 * 예) 3 * 7 = ?
	 * 3. 문제에 해당하는 정답을 입력받는다.
	 * 4. 정답을 비교 "정답" 또는 "땡" 을 출력
	 */
	
	Scanner scan = new Scanner(System.in);
	Random ran = new Random();
	
	int num1 = ran.nextInt(9) +1;
	int num2 = ran.nextInt(9) +1;
	
	System.out.println( num1 + " * "+ num2+  " = " + " ? ");
	
	System.out.println("정답 입력");
	int rNum = scan.nextInt();
	
	int num3 = num1 * num2;
	
	if(num3  == rNum) {
		System.out.println("정답");
	}else {
		System.out.println("떙");
	}
	
	}

}
