package test;
// 시작 : 12 : 30
// 종료 : 15 : 20  
// 소요 : 2시간 소요
import java.util.Scanner;;
public class Test01_6월21일 {

public static void main(String[] args) {
		//문제) 시험점수 3개를 입력받고 학점 출력
		//조건1) 3과목의 평균을 가지고 점수를 매긴다.
		//조건2) 3과목의 평균이 100~90 ==> A
		//조건3) 3과목이 평균이 89~80 ==> B
		//조건4) 3과목이 평균이 79~70 ==> C
		//조건5) 69이하는 			==> 재시험
		//추가조건) 각점수대별로 끝자리가 7점 이상은 +가 붙는다.
		//예) 98 ==> A+
		//예) 87 ==> B+
		//예) 79 ==> C+
		
		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("첫번쨰 과목을 입력하세요");
		int score1 = scan.nextInt();
		
		System.out.println("두번쨰 과목을 입력하세요");
		int score2 = scan.nextInt();
		
		System.out.println("세번쨰 과목을 입력하세요");
		int score3 = scan.nextInt();
		
		int score4 = (score1+score2+score3)/3;
		
		
		if(97 <= score4 && score4 <= 100) {
			System.out.println("A+");
		}else if(90 <= score4 && score4 <= 96) {
			System.out.println("A");
		}else if(87 <= score4 && score4 <= 89) {
			System.out.println("B+");
		}else if(80 <= score4 && score4 <= 86) {
			System.out.println("B");
		}else if(77 <= score4 && score4 <= 79) {
			System.out.println("C+");
		}else if(70 <= score4 && score4 <=76) {
			System.out.println("C");
		}else{
			System.out.println("재시험");
		}
		
		System.out.println("평균은 " + score4 + "점입니다");
	}

}
