package test2;

public class Test02_7월19일 {
	// 시작 11 : 03
	// 종료 16 : 12
	// 소요 
	
	// 증감연산자와 반복문을 사용해서 해결하세요 (산술연산 문제 아님)
	//예)
    // int clap = 3;
    // while(clap > 0) {
    // System.out.println("짝");
    // clap--;
    // }
	
	public static void main(String[] args) {
			
		// 문제1)
		// 윤주네 반 학생은 31명입니다.
		// 이중에서 남학생은 12명, 여학생은 14명이 봉사활동을 하였습니다.
		// 은주네 반에서 봉사활동을 하지 않은 학생은 
		// 몇명인지 출력
		 
		int count = 0;
		for(int i = 31; i > 26; i--) {
			count++;
		}
			System.out.println(count + "명");
		
		// 문제2)
		// 연필 7타를 여학생 2명과 남학생 4명에게 남김없이 똑같이 나누어 주었을떄
		// 한사람은 연필을 몇 자루 가지게 되는지 출력(연필 1타는 12자루)
		// 힌트) 7 * 12 / 6
		int p = 84;
		int count2 = 0;
		while(p > 0) {
			p -= 6;
			count2++;
		}
		System.out.println(count2 + "자루");
				
			
		// 문제3) 
		// 어느 공장에서 한사람이 1시간에 컴퓨터를 4대를 조립할 수 있다고 한다.
		// 3명이 컴퓨터를 96대를 조립하면 몇시간이 걸리는가
		int count3 = 0;
		for(int i = 96; i > 0; i-= 12) {
			count3++;
		}
		System.out.println(count3 + "시간");
		
		// 문제4)
		//귤 6개의 무게는 840g, 사과 3개의 무게는 750g 입니다.
		//귤5개와 사과 4개의 무게는 몇g인지 출력 (단 각각의 귤끼리 무게는 같고 각각의 사과끼리는 무게가같다)
		
		int man = 840;
		int app = 750;
		
		int x = man / 6;
		int y = app / 3;
		
		int totalman = 0;
		int totalapp = 0;
		
		for(int i = 0; i < 5; i++) {
			totalman += x;
		}
		for(int i = 0; i < 4; i++) {
			totalapp += y;
		}
		
		System.out.println("귤5개의 무게 " + totalman + "g");
		System.out.println("사과4개의 무게 " + totalapp + "g");
	}

}
