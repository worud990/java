package test2;

public class Test05_7월21일 {
	// 시작  10 : 35 
	// 종료  11 : 35
	// 소요  1시간
	public static void main(String[] args) {

		//# 문제1) 7의 배수를 차례대로 출력했을떄 8번쨰 배수를 출력
		
		int count = 0;
		for(int i = 1; count < 8; i++) {
			if(i % 7 == 0) {
				count++;
				if(count == 8) {
					System.out.println(i);
				}
			}
		}
		
		//# 문제2) 6과 8의 공약수를 모두 출력
		//# 공약수란 각수의 공통인 약수를 말한다.
		//예) 6 ==> 1,2,3,6
		//	 8 ==> 1,2,4,8
		//# 공약수는 1,2
	
		int x = 6;
		int y = 8;

		for(int z = 1; z <= y; z++) {
			if(x % z == 0 && y % z == 0) {
				System.out.print(z + ",");
			}
		}
		System.out.println();
		
		//# 문제3) 위 수의 최대 공약수 출력
		//# 최대공약수란 공약수 중에서 가장 큰수
		
		int num = 0;
		for(int z = 1; z <= y; z++) {
			if(x % z == 0 && y % z == 0) {
				num =  z;
			}
		}
		System.out.println(num);
		
		//# 문제4) 25, 75의 최대 공약수를 출력
		int a = 25; // 1,5,25
		int b = 75;	// 1.3,5,15,25,75
		int answer = 0;
		for(int z = 1; z <= b; z++) {
			if(a % z == 0 || b % z == 0) {
				answer = a;
			}
		}
			System.out.println(answer);
		//# 문제5) 연필 42자루와 지우개 28개를 최대한 많은 학생에게 남김없이 똑같이 나누어 주려고한다.
		//# 몇명까지 나누어 줄수있는지 출력
		int p = 1;
		int e = 1;
	
		
		int total = 0;
		for(int s = 1; s <= 42; s++) {
			if(42 % s == 0 && 28 % s == 0) {
				total = s;
			}
		}
		System.out.print("최대한 똑같이 나누어 줄 수있는 학생 " + total);
		

	
	}

}
