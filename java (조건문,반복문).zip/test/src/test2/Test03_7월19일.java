package test2;

public class Test03_7월19일 {
	
	public static void main(String[] args) {
		
		// #문제1) 마트에서 오이를 3개씩 묶어서 1500원에 판다고 한다.
		// #오이가 14개 필요하다. 돈이 얼마나필요한가(오이는 묶음으로만 판다)
		/*
		 * 힌트 : 3의 배수가 아니면 될떄까찌 증가시킨다.
		 * while(오이 % 3 != 0){
		 * 		오이 += 1;
		 * }
		 * 
		 */
			int cucumber = 10;
			int price = 1500;

			
			while(cucumber % 3 != 0) {
				System.out.println("오이 " + cucumber + "개를 구매할수없습니다.");
				cucumber += 1;
			}
			while(cucumber % 3 == 0) {
				System.out.println("오이 " + cucumber + "개를 구매했습니다.");
				break;
			}
			
			int totalprice = cucumber / 3 * price;
			System.out.println("필요한 금액은 " + totalprice + "원입니다.");

			
		// #문제2) 민수네 반 학생은 26명입니다.
		// #민수네 반 학생들에게 도화지를 2장씩 나누어 주려고합니다.
		// #도화지는 10장씩 묶음으로만 판매하고 10장에 1200원입니다.
		// #총얼마가 필요한가요?
		
			int student = 26;
			int paper = 10;
			int price2 = 1200;
			
			int total = student * 2;
			
			while(total % paper != 0) {
				total += 1;
			}
			
			int money = (total / paper) * price2;
			System.out.println("필요한 금액 " + money + "원");
			
		// #문제3) 가게에서 24600원짜리 옷을 샀습니다.
		// #1000원짜리 지폐로만 옷값을낸다면 몇장이 필요한가요?
		
			int price3 = 24600;
			int price4 = 1000;
			int count = 0;
			
			while(price3 > 0) {
				price3 -= price4;
				count += 1;
			}
			System.out.println("필요한 지페갯수 " + count + "장");
	}

}
