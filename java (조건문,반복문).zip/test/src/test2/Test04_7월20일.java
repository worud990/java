package test2;

public class Test04_7월20일 {
	// 시작 10 : 10
	// 종료 13 : 18
	// 소요 3시간 8분
	public static void main(String[] args) {

		//# 문제1) 36의 약수를 전부 출력
		//# 약수는 36과 나눠서 나머지가 0인수를 말한다.
		//# 1,2,4,6,...
		int i = 0;
		int num = 1;
		
		while(num <= 36) {
			if(36 % num == 0) {
			i = num;
			System.out.print(i + ",");
			}
			num++;
		}

		System.out.println();
		System.out.println();
		
		//# 문제2) 24의 약수중에서 2의 배수만 출력
		
		for(int x = 1; x <= 24; x++) {
			if(24 % 2 == 0 && x % 2 == 0) {
				System.out.print(x + ",");
			}
		}
		
		System.out.println();
		System.out.println();
		
		//# 문제3) 18의 약수의 갯수 더하기 21의 약수의 갯수를 출력
		int count = 0;
		for(int y = 1; y <= 18; y++) {
			if(18 % y == 0) {
				System.out.print(y + ",");
				count = count + 1;
			}
		}
		System.out.println();
		System.out.println(count + "개");
		
		int count2 = 0;
		for(int z = 1; z <= 21; z++) {
			if(21 % z == 0) {
				System.out.print(z + ",");
				count2 = count2 + 1;
			}
		}
		System.out.println();
		System.out.println(count2 + "개");
		
		//# 문제4) 50부터 100까지의 자연수중에서 9의 배수는 모두 몇개?
		int a = 50;
		int count3 = 0;
		
		while(a <= 100) {
			if(a % 9 == 0) {
				System.out.print(a + ",");
				count3++;
			}
			a++;
		}
		System.out.println();
		System.out.println(count3 + "개");
	}

}
