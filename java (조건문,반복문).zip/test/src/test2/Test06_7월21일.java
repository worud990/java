package test2;

public class Test06_7월21일 {
	// 시작 12 : 00
	// 종료
	// 소요
	public static void main(String[] args) {

		//문제1) 8과 12의 최소 공배수를 구하시요
		//# 최소 공배수란 각 수의 배수를 나열한 다음 처음으로 같은숫자를 말한다.
		//# 예) 8,16,24....
		//# 예) 12,24....
		//# 여기서 24가 최소공배수이다.
		
		int x = 8;
		int y =12;
		
		for(int i = 1; ; i++) {
			if( i % x == 0 && i % y == 0) {
				System.out.println("8과 12의 최소공배수는 " + i + "다");
				break;
			}
		}
		
		//문제2) 수인이는 4일 마다 수영자를 가고 형주는 6일마다 수영장에 간다
		//# 두사람이 4월 3일에 만났다면 다음에 만날날은 언제인가?
		int s = 4;
		int h = 6;
		
		for(int z = 1; ; z++) {
			if(z % s == 0 && z % h == 0) {
				System.out.println("다음에 만날날은 " + (3 + z) + "일이다");
				break;
			}
		}
		//문제3) 가로가 12이고 세로가 8인 직사각형모양의 종이를 늘어놓아
		//# 만들수 있는 가장 작은 정사각형을 만들려고한다. 직사각형은 몇장이 필요한가?
		int a = 12;
		int b= 8;
		int paper = 0;
		
		for(int i = 1; true; i++) {
			if(i % a == 0 && i % b == 0) {
				paper = i;
				break;
			}
		}
		
		int total= (paper / a) * (paper / b);
		System.out.println("필요한 종이 수 " + total + "장");
		
	}

}
